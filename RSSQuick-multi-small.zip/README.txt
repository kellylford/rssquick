RSS Quick - Multi-Platform Distribution 
======================================= 
 
Choose the right folder for your computer: 
 
win-x64\     - For most computers (Intel/AMD) 
win-arm64\   - For ARM computers (Surface Pro X, etc) 
 
Try win-x64 first. If it asks to download .NET, try win-arm64. 
 
Both require .NET 8.0 Runtime to be installed. 
Download from: https://dotnet.microsoft.com/download/dotnet/8.0 
